# Jazpay Accounting Bot
Telegram accounting bot powered by aiogram.